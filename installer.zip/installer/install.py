#https://drive.usercontent.google.com/download?id=1-jykceeDinrDVJ6vMEMxj_AMYu3CnIwo&export=download&authuser=0&confirm=t&uuid=c1f96811-bf0d-4efa-b952-91739ac6c379&at=APZUnTXQ34cUukQGflj8fZMg-dpn:1710518194829
import time, os
try:
    os.system('pip install wget')
    time.sleep(3)
    import wget
except:
    pass
os.system('cls')

def LaunchSteam():
    os.system('start steam/steam.exe')
    os.system('cls')
    print("Make sure to not install any\ndrivers or anything or it\nwon't work. Just press\nignore on any popups.")

def AutomaticInstall(): 
    print("Preparing steam install...")
    time.sleep(5)

    #URL = "https://drive.usercontent.google.com/download?id=1-jykceeDinrDVJ6vMEMxj_AMYu3CnIwo&export=download&authuser=0&confirm=t&uuid=c1f96811-bf0d-4efa-b952-91739ac6c379&at=APZUnTXQ34cUukQGflj8fZMg-dpn:1710518194829"
    URL = "http://host.earthisafaggot.club/"
    os.system('cls')
    print("Installing steam...")
    wget.download(URL, "steam.zip")
    os.system('cls')

    print("Download complete!\nInstalling...")
    time.sleep(3)
    if not os.path.exists("steam.zip"):
        print("Something went wrong! Please try\nagain and delete any leftover files\nfrom the installer!")
    else:
        import zipfile
        with zipfile.ZipFile("steam.zip","r") as steamZip:
            steamZip.extractall("")
        os.system('cls')
        print("Doing finishing touches...")
        os.remove("steam.zip")
        os.system('cls')
        print("Launching Steam...")
        LaunchSteam()
use = input("Press 1 for Automatic install\nPress 2 for Manual install\nPress 3 to start Steam\n\nOnly use manual if automatic\ndoesnt work for some reason.\n\n> ")
if(use == "1"):
    AutomaticInstall()
elif(use == "2"):
    os.system('start msedge "https://drive.usercontent.google.com/download?id=1-jykceeDinrDVJ6vMEMxj_AMYu3CnIwo&export=download&authuser=0"')
elif(use == "3"):
    LaunchSteam()
else:
    print("That doesnt exist ningle.")

time.sleep(10000)