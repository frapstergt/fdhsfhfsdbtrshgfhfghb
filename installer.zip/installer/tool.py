#https://drive.usercontent.google.com/download?id=1-jykceeDinrDVJ6vMEMxj_AMYu3CnIwo&export=download&authuser=0&confirm=t&uuid=c1f96811-bf0d-4efa-b952-91739ac6c379&at=APZUnTXQ34cUukQGflj8fZMg-dpn:1710518194829
import time, os
try:
    os.system('pip install wget')
    time.sleep(3)
    import wget
except:
    pass
os.system("title Frap's School computer multitool.")
os.system('cls')


#games


def LaunchSteam():
    if os.path.exists("steam/steam.exe"):
        os.system('cls')
        print("Make sure to not install any\ndrivers or anything or it\nwon't work. Just press\nignore on any popups.")
        os.system('start steam/steam.exe')
    else:
        print("Steam is not installed.")

def LaunchEpic():
    if os.path.exists("Epic Games/Launcher/Engine\Binaries/Win64/EpicGamesLauncher.exe"):
        os.system('cls')
        print("Make sure to not install any\ndrivers or anything or it\nwon't work. Just press\nignore on any popups.")
        os.system('"Epic Games/Launcher/Engine\Binaries/Win64/EpicGamesLauncher.exe"')
    else:
        print("Epic is not installed.")

def LaunchLethal():
    if os.path.exists("Lethal Company/Lethal Company.exe"):
        os.system('cls')
        print("Playing lethal semen.")
        os.system('"Lethal Company/Lethal Company.exe"')
    else:
        print("Lethal Company is not installed.")

def LaunchAmongus():
    if os.path.exists("Among us/Among us.exe"):
        os.system('cls')
        print("Playing Among us.")
        os.system('"Among us/Among us.exe"')
    else:
        print("Lethal Company is not installed.")

def InstallLethal():
    URL = "https://drive.usercontent.google.com/download?id=1LF9XXTUN5BJxFkdSsXvOWh6GsZm2oS2O&export=download&authuser=0&confirm=t&uuid=24adae6d-44db-4f84-8784-57890246086f&at=APZUnTVEYqd4AGZE3iij_bcXcaf1%3A1710523555222"
    os.system('cls')
    print("Installing lethal...")
    wget.download(URL, "lethalsemen.zip")
    os.system('cls')

    print("Download complete!\nInstalling...")
    time.sleep(3)
    if not os.path.exists("lethalsemen.zip"):
        print("Something went wrong! Please try\nagain and delete any leftover files\nfrom the installer!")
    else:
        import zipfile
        with zipfile.ZipFile("lethalsemen.zip","r") as steamZip:
            steamZip.extractall("")
        os.system('cls')
        print("Doing finishing touches...")
        os.remove("lethalsemen.zip")
        os.system('cls')
        print("Launching Lethal...")
        LaunchLethal()


def InstallAmongus():
    URL = "https://drive.usercontent.google.com/download?id=16i3m8TPva96S5sigcxgdVvxTHqEiDASA&export=download&authuser=0&confirm=t&uuid=31f299b9-0929-43b9-a447-fe5cb8f5cb1f&at=APZUnTXEr9liiv6Nlq5dmTRszplH:1710525212676"
    os.system('cls')
    print("Installing Amongus...")
    wget.download(URL, "amongus.zip")
    os.system('cls')

    print("Download complete!\nInstalling...")
    time.sleep(3)
    if not os.path.exists("amongus.zip"):
        print("Something went wrong! Please try\nagain and delete any leftover files\nfrom the installer!")
    else:
        import zipfile
        with zipfile.ZipFile("amongus.zip","r") as steamZip:
            steamZip.extractall("")
        os.system('cls')
        print("Doing finishing touches...")
        os.remove("amongus.zip")
        os.system('cls')
        print("Launching Amongus...")
        LaunchAmongus()


def AutomaticInstall(): 
    print("Preparing steam install...")
    time.sleep(5)

    #URL = "https://drive.usercontent.google.com/download?id=1-jykceeDinrDVJ6vMEMxj_AMYu3CnIwo&export=download&authuser=0&confirm=t&uuid=c1f96811-bf0d-4efa-b952-91739ac6c379&at=APZUnTXQ34cUukQGflj8fZMg-dpn:1710518194829"
    URL = "http://host.earthisafaggot.club/"
    os.system('cls')
    print("Installing steam...")
    wget.download(URL, "steam.zip")
    os.system('cls')

    print("Download complete!\nInstalling...")
    time.sleep(3)
    if not os.path.exists("steam.zip"):
        print("Something went wrong! Please try\nagain and delete any leftover files\nfrom the installer!")
    else:
        import zipfile
        with zipfile.ZipFile("steam.zip","r") as steamZip:
            steamZip.extractall("")
        os.system('cls')
        print("Doing finishing touches...")
        os.remove("steam.zip")
        os.system('cls')
        print("Launching Steam...")
        LaunchSteam()


def AutomaticEpicInstall(): 
    print("Preparing epic install...")
    time.sleep(5)

    URL = "https://drive.usercontent.google.com/download?id=109T9Ql2xjYWRHuSfqBy0j_8-cocASEAc&export=download&authuser=0&confirm=t&uuid=90db0b25-96d8-4f0c-9d7d-5076e3b9279a&at=APZUnTVDeLMPGuQxyKQRvEfAHVzX:1710527761772"
    os.system('cls')
    print("Installing epic...")
    wget.download(URL, "epic.zip")
    os.system('cls')

    print("Download complete!\nInstalling...")
    time.sleep(3)
    if not os.path.exists("epic.zip"):
        print("Something went wrong! Please try\nagain and delete any leftover files\nfrom the installer!")
    else:
        import zipfile
        with zipfile.ZipFile("epic.zip","r") as steamZip:
            steamZip.extractall("")
        os.system('cls')
        print("Doing finishing touches...")
        os.remove("epic.zip")
        os.system('cls')
        print("Launching Epic...")
        LaunchEpic()



def GameManager():
    gameToInstall = input("Press 1 to install lethal semen\nPress 2 to play lethal semen\nPress 3 to install amongst uz\nPress 4 to play amongst uz\n\n> ")
    
    if(gameToInstall == "1"):
        InstallLethal()
    elif(gameToInstall == "2"):
        LaunchLethal()
    elif(gameToInstall == "3"):
        InstallAmongus()
    elif(gameToInstall == "4"):
        LaunchAmongus()
    else:
        print("That doesnt exist ningle.")


def BepinexInstaller():
    ver = input("Press 1 to install 64x\nPress 2 to install 32x\n\n> ")

    if(ver == "1"):
        wget.download("https://github.com/BepInEx/BepInEx/releases/download/v5.4.22/BepInEx_x64_5.4.22.0.zip", "BepinEx64.zip")
    elif(ver == "2"):
        wget.download("https://github.com/BepInEx/BepInEx/releases/download/v5.4.22/BepInEx_x86_5.4.22.0.zip", "BepinEx32.zip")

def Steam():
    use = input("Press 1 for Automatic Steam install\nPress 2 for Manual Steam install\nPress 3 to start Steam\n\nOnly use manual if automatic\ndoesnt work for some reason.\n\n> ")

    if(use == "1"):
        AutomaticInstall()
    elif(use == "2"):
        os.system('start msedge "https://drive.usercontent.google.com/download?id=1-jykceeDinrDVJ6vMEMxj_AMYu3CnIwo&export=download&authuser=0"')
    elif(use == "3"):
        LaunchSteam()
    else:
        print("That doesnt exist ningle.")

def Epic():
    use = input("Press 1 for Automatic Epic install\nPress 2 for Manual Epic install\nPress 3 to start Epic\n\nOnly use manual if automatic\ndoesnt work for some reason.\n\n> ")

    if(use == "1"):
        AutomaticEpicInstall()
    elif(use == "2"):
        os.system('start msedge "https://drive.usercontent.google.com/download?id=109T9Ql2xjYWRHuSfqBy0j_8-cocASEAc&export=download&authuser=0"')
    elif(use == "3"):
        LaunchEpic()
    else:
        print("That doesnt exist ningle.")

def Games():
    use = input("Press 1 for Steam options\nPress 2 for Epic options\nPress 3 to install games\nPress 4 for bepinex\n\n> ")
    if(use == "1"):
        os.system('cls')
        Steam()
    elif(use == "2"):
        os.system('cls')
        Epic()
    elif(use == "3"):
        os.system('cls')
        GameManager()
    elif(use == "4"):
        BepinexInstaller()
    else:
        print("That doesnt exist ningle.")


#useful sites
        
def goto(url : str):
    os.system(f'start msedge "{url}"')
    
        
def UsefulSites():
    site = input("Press 1 for classroom 6x\nPress 2 for unblocked 76\nPress 3 for google classroom\nPress 4 for scratch\nPress 5 for eaglercraft\n\n> ")
    if(site == "1"):
        goto("https://sites.google.com/site/classroom6x/")
    elif(site == "2"):
        goto("https://sites.google.com/site/unblockedgame76/")
    elif(site == "3"):
        goto("https://classroom.google.com")
    elif(site == "4"):
        goto("https://scratch.mit.edu")
    elif(site == "5"):
        goto("https://eaglercraft.com/mc/1.8.8/")
    else:
        print("This site doesnt exist!")

#multitool

while True:
    use = input("Press 1 for Games\nPress 2 for Useful Sites\n\n> ")
    if(use == "1"):
        os.system('cls')
        Games()
    elif(use == "2"):
        os.system('cls')
        UsefulSites()
    else:
        print("That doesnt exist ningle.")

    print("")
    os.system('pause')
    os.system('cls')